// Use this file to store all of the private credentials 
// and connection details

#define SECRET_SSID "ESPServer_RAJ"		// replace MySSID with your WiFi network name
#define SECRET_PASS "RAJ@12345"	// replace MyPassword with your WiFi password

#define SECRET_CH_ID 1317597			// replace 0000000 with your channel number
#define SECRET_WRITE_APIKEY "S72C14OKE1009FSS"   // replace XYZ with your channel write API Key
